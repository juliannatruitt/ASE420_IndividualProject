import sys
import sqlite3
from datetime import date

connect = sqlite3.connect('users_entries_data_prototype.db')
cursor = connect.cursor()

selectOrQuery = sys.argv[1]
tag = sys.argv[len(sys.argv)-1]


if selectOrQuery == 'record':
    #check to make sure tag starts with : and then remove it so we can store the proper table without error
    if tag.startswith(":"):
        tag = tag[1:]
    #date is the second input, check if date is in proper format and if user enters "today" convert it into a date
    dateEntered = sys.argv[2]
    if dateEntered.startswith("today") or dateEntered.startswith("Today"):
        dateEntered = date.today().strftime("%Y/%m/%d")

    starttime = sys.argv[3]
    endtime = sys.argv[4]
    #get the full length of the description to be stored. Ww know description starts at index 5 and ends before the tag
    if sys.argv[5].startswith("'") or sys.argv[5].startswith("\""):
        total_lines_of_description = ''
        for x in range(5, len(sys.argv)-1):
            total_lines_of_description += sys.argv[x] + ' '


    # search the database for the tag
    checkIfCreated = cursor.execute(f"""SELECT name FROM sqlite_master WHERE type='table' AND name='{tag}'""").fetchone()
    if checkIfCreated and total_lines_of_description is not None:
        cursor.execute(f"""INSERT into {tag}(date, starttime, endtime, description) VALUES('{dateEntered}','{starttime}','{endtime}', {total_lines_of_description})""")
        print(f"recorded entry into table {tag}")
        connect.commit()
    # if tag does not exist, create a new table
    else:
        cursor.execute(f"""CREATE TABLE {tag}(
                        date text,
                        starttime text,
                        endtime text,
                        description text)""")
        print("table created")
        cursor.execute(f"""INSERT into {tag}(date, starttime, endtime, description) VALUES('{dateEntered}','{starttime}','{endtime}', {total_lines_of_description})""")
        connect.commit()
        print("Recorded entry!")


if selectOrQuery == 'query':
    if tag.startswith(":"):
        tag = tag[1:]
        checkIfCreated = cursor.execute(f"""SELECT name FROM sqlite_master WHERE type='table' AND name='{tag}'""").fetchone()
        if checkIfCreated:
            rows = cursor.execute(f"SELECT * FROM {tag}").fetchall()
            for row in rows:
                print(row)

        else:
            print("tag does not exist!, create that tag using the record command")

    elif tag.startswith("\"") or tag.startswith("'"):
        tag = tag.replace("\"", "",2)
        tag = tag.replace("'", "", 2)
        #search every table in the database
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        for tablerow in cursor.fetchall():
            table = tablerow[0]
            cursor.execute(f"SELECT * FROM {table}")
            for row in cursor:
                if tag in row[3]:
                    print(row)

    elif tag[0].isdigit() or tag.startswith("today"):
        if tag.startswith("today"):
            tag = date.today().strftime("%Y/%m/%d")

        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        for tablerow in cursor.fetchall():
            table = tablerow[0]
            cursor.execute(f"SELECT * FROM {table}")
            for row in cursor:
                if tag in row[0]:
                    print(row)
    else:
        print("You are incorrectly entering data. Examples of correct queries are 1. query today 2. query :STUDY or 3. query 'java'")
