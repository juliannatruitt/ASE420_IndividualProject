from datetime import date


class Record(object):
    def __init__(self, dateEntered, starttime, endtime, description, tag, connection):
        self._dateEntered = dateEntered
        self._starttime = starttime
        self._endtime = endtime
        self._description = description
        self._tag = tag
        self._connection = connection

    def get_date(self):
        return self._dateEntered

    def set_date(self, newDate):
        self._dateEntered = newDate

    def get_starttime(self):
        return self._starttime

    def get_endtime(self):
        return self._endtime

    def get_description(self):
        return self._description

    def get_tag(self):
        return self._tag

    def set_tag(self, new_tag):
        self._tag = new_tag

    def get_database(self):
        return self._connection

    def remove_colon_from_tag(self):
        if self.get_tag().startswith(":"):
            self.set_tag(self.get_tag()[1:])

    def recordTable(self):
        self.remove_colon_from_tag()
        if self.get_date().startswith("today") or self.get_date().startswith("Today"):
            self.set_date(date.today().strftime("%Y/%m/%d"))
        if self.checkIfTableAlreadyCreated() is not None:
            self.insertIntoTable()
        else:
            self.createTable()
            self.insertIntoTable()
            print("table created and entry recorded")
            self.get_database().get_connection().commit()

    def insertIntoTable(self):
        self.get_database().cursor().execute(f"""INSERT into {self.get_tag()} (date, starttime, endtime, description) 
                                            VALUES('{self.get_date()}','{self.get_starttime()}','{self.get_endtime()}', {self.get_description()})""")
        print(f"recorded entry into table {self.get_tag()}")
        self.get_database().get_connection().commit()

    def checkIfTableAlreadyCreated(self):
        return self.get_database().cursor().execute(
            f"""SELECT name FROM sqlite_master WHERE type='table' AND name='{self.get_tag()}'""").fetchone()

    def createTable(self):
        self.get_database().cursor().execute(f"""CREATE TABLE {self.get_tag()}(
                            date text,
                            starttime text,
                            endtime text,
                            description text)""")
        print("table created")
        self.get_database().get_connection().commit()