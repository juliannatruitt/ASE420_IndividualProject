import sqlite3


class CreateConnection(object):
    def __init__(self, database_name):
        self._connect = sqlite3.connect(database_name)

    def get_connection(self):
        return self._connect

    def cursor(self):
        return self.get_connection().cursor()