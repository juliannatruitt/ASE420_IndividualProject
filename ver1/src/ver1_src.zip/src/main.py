import sys
from Connection import CreateConnection
from Query import Query
from CheckInputValues import CheckInputValuesRecord


if __name__ == "__main__":

    if sys.argv[1] == "query" or sys.argv[1] == "Query" or sys.argv[1] == "QUERY":
        connection = CreateConnection("ver1_database.db")
        Query(sys.argv[len(sys.argv) - 1], connection).deciding_what_to_query()

    elif sys.argv[1] == "record" or sys.argv[1] == "Record" or sys.argv[1] == "RECORD":
        connection = CreateConnection("ver1_database.db")
        CheckInputValuesRecord(sys.argv, connection).check_all()

    else:
        print("incorrectly entered a record or query. Check syntax and try again")