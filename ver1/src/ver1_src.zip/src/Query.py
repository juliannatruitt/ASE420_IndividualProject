from datetime import date


class Query(object):
    def __init__(self, query_value, database):
        self._query_value = query_value
        self._database = database

    def get_query(self):
        return self._query_value

    def set_query(self, new_query):
        self._query_value = new_query

    def get_database(self):
        return self._database

    def deciding_what_to_query(self):
        if self.get_query().startswith(":"):
            self.set_query(self.get_query()[1:])
            self.query_tag()
        elif self.get_query().startswith("'") or self.get_query().startswith("\""):
            self.set_query(self.get_query().replace("\"", "", 2))
            self.set_query(self.get_query().replace("'", "", 2))
            self.query_description()
        elif self.get_query()[0].isdigit or self.get_query().startswith("today") or self.get_query().startswith(
                "Today"):
            if self.get_query().startswith("today") or self.get_query().startswith("Today"):
                self.set_query(date.today().strftime("%Y/%m/%d"))
            self.query_date()
        else:
            print("error in the query you entered. Check to make sure you syntax is corrected")

    def query_tag(self):
        table_created_or_not = self.checkIfTableAlreadyCreated()
        if table_created_or_not:
            rows = self.get_database().cursor().execute(f"SELECT * FROM {self.get_query()}").fetchall()
            for row in rows:
                print(row)
        else:
            print("tag does not exist!, create that tag using the record command")

    def query_description(self):
        alltables = self.get_database().cursor().execute("SELECT name FROM sqlite_master WHERE type='table'")
        for tablerow in alltables.fetchall():
            table = tablerow[0]
            alltables.execute(f"SELECT * FROM {table}")
            for row in alltables:
                # description (or task) is located in row 3
                if self.get_query() in row[3]:
                    print(row)

    def query_date(self):
        row_returned = False
        alltables = self.get_database().cursor().execute("SELECT name FROM sqlite_master WHERE type='table'")
        for tablerow in alltables.fetchall():
            table = tablerow[0]
            alltables.execute(f"SELECT * FROM {table}")
            for row in alltables:
                if self.get_query() == row[0]:
                    print(row)
                    row_returned = True
        if not row_returned:
            print("You entered a date that has no records. Try again")

    def checkIfTableAlreadyCreated(self):
        return self.get_database().cursor().execute(
            f"""SELECT name FROM sqlite_master WHERE type='table' AND name='{self.get_query()}'""").fetchone()

