from Full_Description import GetFullDescription
from Connection import CreateConnection
import re
from Record import Record


class CheckInputValuesRecord(object):
    def __init__(self, argument):
        self.argument = argument
        self.description = GetFullDescription(self.argument[5:len(self.argument) - 1]).get_description_input()
        self.connection = CreateConnection("ver1_database.db")

    def isValidLength(self):
        isValid = False
        if len(self.argument) >= 6:
            isValid = True
        else:
            print("Did not include enough information in your record, review format and try again")
        return isValid

    def record_entered_correctly(self, index):
        isValid = False
        if index == "record" or index == "Record" or index == "RECORD":
            isValid = True
        return isValid

    def date_entered_correctly(self, index):
        isValid = False
        pattern1 = r"^\d{4}/\d{2}/\d{2}$"
        if re.match(pattern1, index):
            isValid = True
        elif index == 'today' or index == 'Today':
            isValid = True

        else:
            print("invalid date entered, user format YYYY/mm/dd")
        return isValid

    def get_correct_time_entered(self, index):
        isValid = False
        pattern1 = r"^\d{2}:\d{2}$"
        pattern2 = r"^\d{2}:\d{2}[ap]m$"
        pattern3 = r"^\d{1}:\d{2}$"
        pattern4 = r"^\d{1}:\d{2}[ap]m$"
        if re.match(pattern1, index) or re.match(pattern2, index) or re.match(pattern3, index) or re.match(pattern4, index):
            isValid = True
        return isValid

    def check_description(self):
        isValid = False
        if self.description.startswith("'") and self.description[len(self.description)-2].startswith("'"): #-2 because last character is a space
            isValid = True
        else:
            print("description not entered in the right format. Make sure it starts with ' and ends with '")
        return isValid

    def check_tag(self):
        isValid = False
        if self.argument[len(self.argument) - 1].startswith(":"):
            isValid = True
        else:
            print("tag entered incorrectly, make sure to put a : beforehand")
        return isValid

    def check_all(self):
        if (self.isValidLength() and self.record_entered_correctly(self.argument[1]) and self.date_entered_correctly(self.argument[2]) and
                self.get_correct_time_entered(self.argument[3]) and self.get_correct_time_entered(self.argument[4]) and
                self.check_description() and self.check_tag()):
            Record(self.argument[2], self.argument[3], self.argument[4], self.description,
                   self.argument[len(self.argument) - 1],
                   self.connection).recordTable()
